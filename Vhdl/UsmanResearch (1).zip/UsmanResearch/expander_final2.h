#ifndef EXPANDER_FINAL2_H_
#define EXPANDER_FINAL2_H_

#include "expander_generate2.h"

void printHeader_expander_final2(ofstream &fout, int size1, int size2, int outSize);
void create_expander_module2(int size1,int size2);

#endif