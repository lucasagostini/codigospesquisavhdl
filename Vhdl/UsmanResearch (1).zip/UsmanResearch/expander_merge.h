#ifndef EXPANDER_MERGE_H_
#define EXPANDER_MERGE_H_

#include "common.h"

using namespace std;

void printHeader_expander_merge(ofstream& fout, int entangledSize, int outSize);
void expander_merge(int entangledSize);

#endif