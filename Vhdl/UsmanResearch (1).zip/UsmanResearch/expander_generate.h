#ifndef EXPANDER_GENERATE_H_
#define EXPANDER_GENERATE_H_

#include "common.h"

using namespace std;

void printHeader_expander_generate(ofstream& fout, int numQubits);
void expander_generate(int numQubits);

#endif
