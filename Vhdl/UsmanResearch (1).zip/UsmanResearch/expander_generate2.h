#ifndef EXPANDER_GENERATE2_H_
#define EXPANDER_GENERATE2_H_

#include "common.h"

using namespace std;

void printHeader_expander_generate2(ofstream& fout, int size1,int size2);
void expander_generate2(int size1,int size2);

#endif
