#ifndef COMMON_H_
#define COMMON_H_

#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <stdlib.h>
#include <assert.h>
#endif